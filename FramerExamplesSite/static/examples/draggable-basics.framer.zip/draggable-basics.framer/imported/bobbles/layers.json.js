window.__imported__ = window.__imported__ || {};
window.__imported__["bobbles/layers.json.js"] = [
	{
		"id": 27,
		"name": "bobbleJosh",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 800,
			"height": 734
		},
		"maskFrame": null,
		"image": {
			"path": "images/bobbleJosh.png",
			"frame": {
				"x": 32,
				"y": 36,
				"width": 146,
				"height": 146
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1117496245"
	},
	{
		"id": 15,
		"name": "bobbleKayleigh",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 800,
			"height": 734
		},
		"maskFrame": null,
		"image": {
			"path": "images/bobbleKayleigh.png",
			"frame": {
				"x": 278,
				"y": 36,
				"width": 146,
				"height": 146
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "1486868334"
	},
	{
		"id": 32,
		"name": "bobbleKeeg",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 800,
			"height": 734
		},
		"maskFrame": null,
		"image": {
			"path": "images/bobbleKeeg.png",
			"frame": {
				"x": 524,
				"y": 36,
				"width": 146,
				"height": 146
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "254390707"
	}
]