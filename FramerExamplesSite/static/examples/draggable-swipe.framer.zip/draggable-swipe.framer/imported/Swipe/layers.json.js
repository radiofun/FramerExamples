window.__imported__ = window.__imported__ || {};
window.__imported__["Swipe/layers.json.js"] = [
	{
		"id": "02A83424-6F6D-40AC-8FAA-C26E8D3170AD",
		"name": "iphone",
		"maskFrame": null,
		"layerFrame": {
			"x": 143,
			"y": 157,
			"width": 804,
			"height": 1644
		},
		"image": {
			"path": "images/02A83424-6F6D-40AC-8FAA-C26E8D3170AD.png",
			"frame": {
				"x": 143,
				"y": 157,
				"width": 804,
				"height": 1644
			}
		},
		"imageType": "png",
		"modification": null,
		"children": [],
		"visible": true
	},
	{
		"id": "470F041D-8A46-4EFD-A712-9D74FC525357",
		"name": "bg",
		"maskFrame": {
			"x": 229,
			"y": 414,
			"width": 640,
			"height": 1136
		},
		"layerFrame": {
			"x": 229,
			"y": 414,
			"width": 640,
			"height": 1136
		},
		"image": {
			"path": "images/470F041D-8A46-4EFD-A712-9D74FC525357.png",
			"frame": {
				"x": 229,
				"y": 414,
				"width": 640,
				"height": 1136
			}
		},
		"imageType": "png",
		"modification": null,
		"children": [
			{
				"id": "1B78257E-9319-4A71-BB12-715B4FE6A1F7",
				"name": "firstScreen",
				"maskFrame": null,
				"layerFrame": {
					"x": 229,
					"y": 414,
					"width": 640,
					"height": 1136
				},
				"image": {
					"path": "images/1B78257E-9319-4A71-BB12-715B4FE6A1F7.png",
					"frame": {
						"x": 229,
						"y": 414,
						"width": 640,
						"height": 1136
					}
				},
				"imageType": "png",
				"modification": null,
				"children": [],
				"visible": true
			},
			{
				"id": "6D24AF57-C6EE-49A0-B106-094064C4F823",
				"name": "secondScreen",
				"maskFrame": null,
				"layerFrame": {
					"x": 229,
					"y": 414,
					"width": 640,
					"height": 1136
				},
				"image": {
					"path": "images/6D24AF57-C6EE-49A0-B106-094064C4F823.png",
					"frame": {
						"x": 229,
						"y": 414,
						"width": 640,
						"height": 1136
					}
				},
				"imageType": "png",
				"modification": null,
				"children": [],
				"visible": true
			}
		],
		"visible": true
	}
]