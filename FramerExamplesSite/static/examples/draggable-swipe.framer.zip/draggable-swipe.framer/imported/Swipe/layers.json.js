window.__imported__ = window.__imported__ || {};
window.__imported__["Swipe/layers.json.js"] = [
	{
		"id": "E3F62F2B-C4A0-473B-8E92-A282D997AF31",
		"name": "Portrait",
		"maskFrame": null,
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 1000,
			"height": 2000
		},
		"image": {
			"path": "images/Portrait/E3F62F2B-C4A0-473B-8E92-A282D997AF31.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 1000,
				"height": 2000
			}
		},
		"imageType": "png",
		"modification": null,
		"children": [
			{
				"id": "470F041D-8A46-4EFD-A712-9D74FC525357",
				"name": "bg",
				"maskFrame": {
					"x": 169,
					"y": 354,
					"width": 640,
					"height": 1136
				},
				"layerFrame": {
					"x": 169,
					"y": 354,
					"width": 640,
					"height": 1136
				},
				"image": {
					"path": "images/Portrait/470F041D-8A46-4EFD-A712-9D74FC525357.png",
					"frame": {
						"x": 169,
						"y": 354,
						"width": 640,
						"height": 1136
					}
				},
				"imageType": "png",
				"modification": null,
				"children": [
					{
						"id": "7BC5AE59-99CB-4E81-9682-C214680AF691",
						"name": "firstScreen",
						"maskFrame": null,
						"layerFrame": {
							"x": 169,
							"y": 354,
							"width": 640,
							"height": 1136
						},
						"image": {
							"path": "images/Portrait/7BC5AE59-99CB-4E81-9682-C214680AF691.png",
							"frame": {
								"x": 169,
								"y": 354,
								"width": 640,
								"height": 1136
							}
						},
						"imageType": "png",
						"modification": null,
						"children": [],
						"visible": true
					},
					{
						"id": "B7D2CA4E-DC50-476A-9CB9-43FA8AA2FEB1",
						"name": "secondScreen",
						"maskFrame": null,
						"layerFrame": {
							"x": 169,
							"y": 354,
							"width": 640,
							"height": 1136
						},
						"image": {
							"path": "images/Portrait/B7D2CA4E-DC50-476A-9CB9-43FA8AA2FEB1.png",
							"frame": {
								"x": 169,
								"y": 354,
								"width": 640,
								"height": 1136
							}
						},
						"imageType": "png",
						"modification": null,
						"children": [],
						"visible": true
					}
				],
				"visible": true
			},
			{
				"id": "02A83424-6F6D-40AC-8FAA-C26E8D3170AD",
				"name": "iphone",
				"maskFrame": null,
				"layerFrame": {
					"x": 83,
					"y": 97,
					"width": 804,
					"height": 1644
				},
				"image": {
					"path": "images/Portrait/02A83424-6F6D-40AC-8FAA-C26E8D3170AD.png",
					"frame": {
						"x": 83,
						"y": 97,
						"width": 804,
						"height": 1644
					}
				},
				"imageType": "png",
				"modification": null,
				"children": [],
				"visible": true
			}
		],
		"visible": true
	}
]